from distutils.core import setup

setup(name='VigorUtil',version='1.0',description='vigor工具类',author='vigor', py_modules=['FirstMoudel'])